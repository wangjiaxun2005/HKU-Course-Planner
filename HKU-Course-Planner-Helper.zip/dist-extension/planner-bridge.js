(function() {
	var SIS_SYNC_TERMS = ["2026-27 Sem 1", "2026-27 Sem 2"];
	function normalizeCourseCode(value) {
		return value.toUpperCase().replace(/\s+/g, "").trim();
	}
	function isRecord(value) {
		return Boolean(value) && typeof value === "object" && !Array.isArray(value);
	}
	function cleanString(value) {
		return typeof value === "string" ? value.trim() : "";
	}
	function validateSisSyncPlan(input) {
		const errors = [];
		if (!isRecord(input)) return {
			ok: false,
			errors: ["Sync plan must be an object."]
		};
		const jobId = cleanString(input.jobId);
		const academicYear = cleanString(input.academicYear);
		const term = cleanString(input.term);
		const career = cleanString(input.career);
		const rawCourses = Array.isArray(input.courses) ? input.courses : [];
		if (input.protocolVersion !== 1) errors.push("Unsupported sync protocol version.");
		if (!jobId) errors.push("A job ID is required.");
		if (!academicYear) errors.push("Academic year is required.");
		if (!SIS_SYNC_TERMS.includes(term)) errors.push("Unsupported target term.");
		if (term && academicYear && !term.startsWith(academicYear)) errors.push("Academic year does not match the target term.");
		if (career !== "UG") errors.push("Only the UG career is supported.");
		if (rawCourses.length < 1 || rawCourses.length > 6) errors.push("A sync plan must contain between one and six courses.");
		const courses = [];
		const courseCodes = /* @__PURE__ */ new Set();
		for (const [index, rawCourse] of rawCourses.entries()) {
			if (!isRecord(rawCourse)) {
				errors.push(`Course ${index + 1} is invalid.`);
				continue;
			}
			const courseCode = normalizeCourseCode(cleanString(rawCourse.courseCode));
			const title = cleanString(rawCourse.title);
			const subclass = cleanString(rawCourse.subclass).toUpperCase();
			const classNumber = cleanString(rawCourse.classNumber);
			if (!courseCode || !title || !subclass || !classNumber) {
				errors.push(`Course ${index + 1} is missing code, title, subclass, or class number.`);
				continue;
			}
			if (courseCodes.has(courseCode)) {
				errors.push(`Duplicate course ${courseCode}.`);
				continue;
			}
			courseCodes.add(courseCode);
			courses.push({
				courseCode,
				title,
				subclass,
				classNumber
			});
		}
		if (errors.length) return {
			ok: false,
			errors
		};
		return {
			ok: true,
			value: {
				protocolVersion: 1,
				jobId,
				academicYear,
				term,
				career: "UG",
				courses
			}
		};
	}
	function validateSisFullYearSyncPlan(input) {
		if (!isRecord(input)) return {
			ok: false,
			errors: ["Sync plan must be an object."]
		};
		const jobId = cleanString(input.jobId);
		const academicYear = cleanString(input.academicYear);
		const career = cleanString(input.career);
		const rawTerms = Array.isArray(input.terms) ? input.terms : [];
		const errors = [];
		if (input.protocolVersion !== 2) errors.push("Unsupported full-year sync protocol version.");
		if (!jobId) errors.push("A job ID is required.");
		if (!academicYear) errors.push("Academic year is required.");
		if (career !== "UG") errors.push("Only the UG career is supported.");
		if (rawTerms.length !== SIS_SYNC_TERMS.length) errors.push("A full-year sync plan must contain Sem 1 and Sem 2 exactly once.");
		const terms = [];
		for (const [index, rawTerm] of rawTerms.entries()) {
			if (!isRecord(rawTerm)) {
				errors.push(`Term ${index + 1} is invalid.`);
				continue;
			}
			const term = cleanString(rawTerm.term);
			const validation = validateSisSyncPlan({
				protocolVersion: 1,
				jobId,
				academicYear,
				career,
				term,
				courses: rawTerm.courses
			});
			if (!validation.ok) {
				errors.push(...validation.errors.map((error) => `${term || `Term ${index + 1}`}: ${error}`));
				continue;
			}
			terms.push({
				term: validation.value.term,
				courses: validation.value.courses
			});
		}
		const termNames = terms.map((term) => term.term);
		if (new Set(termNames).size !== termNames.length) errors.push("A full-year sync plan cannot contain duplicate terms.");
		for (const required of SIS_SYNC_TERMS) if (!termNames.includes(required)) errors.push(`Missing ${required}.`);
		if (errors.length) return {
			ok: false,
			errors
		};
		return {
			ok: true,
			value: {
				protocolVersion: 2,
				jobId,
				academicYear,
				career: "UG",
				terms: SIS_SYNC_TERMS.map((term) => terms.find((candidate) => candidate.term === term))
			}
		};
	}
	//#endregion
	//#region extension/src/job.ts
	var EXTENSION_RUNTIME_VERSION = "0.4.0";
	//#endregion
	//#region extension/src/planner-port.ts
	var PLANNER_PORT_NAME = "hku-course-planner-bridge-v1";
	function createPlannerPortClient(port, onDisconnect) {
		let connected = true;
		let nextRequest = 1;
		const pending = /* @__PURE__ */ new Map();
		port.onMessage.addListener((message) => {
			const response = message && typeof message === "object" ? message : {};
			if (response.type !== "PLANNER_PORT_RESPONSE" || typeof response.requestId !== "string") return;
			const resolve = pending.get(response.requestId);
			if (!resolve) return;
			pending.delete(response.requestId);
			resolve(response.response);
		});
		port.onDisconnect.addListener(() => {
			if (!connected) return;
			connected = false;
			for (const resolve of pending.values()) resolve({
				ok: false,
				error: "EXTENSION_CONTEXT_INVALID"
			});
			pending.clear();
			onDisconnect();
		});
		return {
			isConnected: () => connected,
			request(message) {
				if (!connected) return Promise.resolve({
					ok: false,
					error: "EXTENSION_CONTEXT_INVALID"
				});
				const requestId = `planner-${nextRequest}`;
				nextRequest += 1;
				return new Promise((resolve) => {
					pending.set(requestId, resolve);
					try {
						port.postMessage({
							type: "PLANNER_PORT_REQUEST",
							requestId,
							message
						});
					} catch {
						pending.delete(requestId);
						connected = false;
						resolve({
							ok: false,
							error: "EXTENSION_CONTEXT_INVALID"
						});
						onDisconnect();
					}
				});
			}
		};
	}
	//#endregion
	//#region extension/src/planner-bridge.ts
	var PLANNER_SOURCE = "hku-course-planner";
	var EXTENSION_SOURCE = "hku-course-planner-helper";
	var extensionContextStale = false;
	var plannerClient = null;
	function reply(type, detail = {}) {
		window.postMessage({
			source: EXTENSION_SOURCE,
			type,
			...detail
		}, window.location.origin);
	}
	function markExtensionContextStale() {
		if (extensionContextStale) return;
		extensionContextStale = true;
		window.removeEventListener("message", handlePlannerMessage);
		reply("EXTENSION_STALE", { message: "The Chrome helper was updated. Reload this Planner tab before continuing." });
	}
	function connectPlannerPort() {
		try {
			const runtime = typeof chrome === "undefined" ? void 0 : chrome.runtime;
			if (!runtime?.id || typeof runtime.connect !== "function") return null;
			return createPlannerPortClient(runtime.connect({ name: PLANNER_PORT_NAME }), markExtensionContextStale);
		} catch {
			return null;
		}
	}
	function handlePlannerMessage(event) {
		if (extensionContextStale || !plannerClient?.isConnected()) return;
		if (event.source !== window || event.origin !== window.location.origin) return;
		if (event.data?.source !== PLANNER_SOURCE) return;
		if (event.data.type === "PLANNER_PING") {
			plannerClient.request({ type: "PING" }).then((rawResponse) => {
				const response = rawResponse && typeof rawResponse === "object" ? rawResponse : {};
				if (!response.ok) return;
				reply("EXTENSION_READY", {
					extensionVersion: response.extensionVersion || "0.4.0",
					mode: "full-year-sync",
					jobPhase: response.job?.phase,
					jobMessage: response.job?.message,
					detectedPage: response.job?.lastDetectedPage
				});
			});
			return;
		}
		if (event.data.type !== "START_SYNC") return;
		const validation = validateSisFullYearSyncPlan(event.data.plan);
		if (!validation.ok) {
			reply("SYNC_REJECTED", { message: validation.errors.join(" ") });
			return;
		}
		plannerClient.request({
			type: "START_SYNC",
			plan: validation.value
		}).then((rawResponse) => {
			const response = rawResponse && typeof rawResponse === "object" ? rawResponse : {};
			if (response.ok) reply("SYNC_ACCEPTED", {
				jobId: response.jobId,
				extensionVersion: response.extensionVersion,
				mode: "full-year-sync"
			});
			else if (response.error !== "EXTENSION_CONTEXT_INVALID") reply("SYNC_REJECTED", { message: response.errors?.join(" ") || response.error || "The extension could not start this sync." });
		});
	}
	window.addEventListener("message", handlePlannerMessage);
	plannerClient = connectPlannerPort();
	if (plannerClient) reply("EXTENSION_READY", {
		extensionVersion: EXTENSION_RUNTIME_VERSION,
		mode: "full-year-sync"
	});
	else markExtensionContextStale();
	//#endregion
})();
