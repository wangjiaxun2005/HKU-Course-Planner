(function() {
	//#region shared/sis-sync.ts
	function normalizeCourseCode(value) {
		return value.toUpperCase().replace(/\s+/g, "").trim();
	}
	function sameSisCourse(left, right) {
		return normalizeCourseCode(left.courseCode) === normalizeCourseCode(right.courseCode) && left.subclass.trim().toUpperCase() === right.subclass.trim().toUpperCase() && left.classNumber.trim() === right.classNumber.trim();
	}
	function computeSisSyncDiff(plan, cart) {
		const targetCodes = new Set(plan.courses.map((course) => normalizeCourseCode(course.courseCode)));
		const add = [];
		const replace = [];
		const correct = [];
		for (const target of plan.courses) {
			const current = cart.filter((course) => normalizeCourseCode(course.courseCode) === normalizeCourseCode(target.courseCode));
			if (!current.length) add.push(target);
			else if (current.some((course) => sameSisCourse(target, course))) correct.push(target);
			else replace.push({
				target,
				current
			});
		}
		return {
			add,
			replace,
			correct,
			remove: cart.filter((course) => {
				const code = normalizeCourseCode(course.courseCode);
				if (!targetCodes.has(code)) return true;
				const target = plan.courses.find((candidate) => normalizeCourseCode(candidate.courseCode) === code);
				const targetAlreadyExists = Boolean(target && cart.some((candidate) => sameSisCourse(target, candidate)));
				return Boolean(target && targetAlreadyExists && !sameSisCourse(target, course));
			})
		};
	}
	//#endregion
	//#region extension/src/job.ts
	function reconcileCourseResults(termPlan, currentResults, diff, completed) {
		const correctCodes = new Set(diff.correct.map((course) => course.courseCode));
		return termPlan.courses.map((course) => {
			const previous = currentResults.find((result) => result.courseCode === course.courseCode);
			if (course.courseCode === completed?.courseCode) return {
				courseCode: course.courseCode,
				status: completed.status
			};
			if (correctCodes.has(course.courseCode)) {
				const preservedStatus = previous && [
					"added",
					"replaced",
					"restored"
				].includes(previous.status) ? previous.status : "correct";
				return {
					courseCode: course.courseCode,
					status: preservedStatus
				};
			}
			return {
				courseCode: course.courseCode,
				status: "pending"
			};
		});
	}
	function activeTermPlan(job) {
		return job.plan.terms[job.activeTermIndex];
	}
	function activeTermProgress(job) {
		return job.termProgress[job.activeTermIndex];
	}
	function diagnosticSummary(job) {
		return [
			`Protocol: ${job.plan.protocolVersion}`,
			`Extension: ${job.extensionVersion}`,
			`Mode: ${job.mode}`,
			`Job: ${job.plan.jobId}`,
			`Active term: ${activeTermPlan(job).term}`,
			`Phase: ${job.phase}`,
			`Checkpoint: ${job.checkpoint}`,
			`Detected page: ${job.lastDetectedPage || "none"}`,
			`Detected URL: ${job.lastDetectedUrl || "none"}`,
			`Message: ${job.message}`,
			...job.termProgress.flatMap((term) => [`${term.term}: ${term.status}`, ...term.results.map((result) => `  ${result.courseCode}: ${result.status}${result.errorCode ? ` (${result.errorCode})` : ""}`)])
		].join("\n");
	}
	//#endregion
	//#region extension/src/sis-dom.ts
	function compactText(value) {
		return (value || "").replace(/\s+/g, " ").trim();
	}
	function escapeRegExp(value) {
		return value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
	}
	function sisTermAliases(term) {
		const academicYear = term.slice(0, 7);
		const semester = term.endsWith("Sem 1") ? "1" : "2";
		const ordinal = semester === "1" ? "First" : "Second";
		return [
			`${academicYear} Sem ${semester}`,
			`${academicYear} Semester ${semester}`,
			`${academicYear} ${ordinal} Semester`
		];
	}
	function textMatchesSisTerm(text, term) {
		const normalized = compactText(text).toLowerCase();
		return sisTermAliases(term).some((alias) => normalized.includes(alias.toLowerCase()));
	}
	function pageShowsSisTerm(documentRoot, term) {
		if (Array.from(documentRoot.querySelectorAll("option:checked")).some((option) => textMatchesSisTerm(option.textContent || "", term))) return true;
		if (Array.from(documentRoot.querySelectorAll("input[type='radio']:checked, input[type='checkbox']:checked")).map((control) => control.closest("tr")).filter((row) => Boolean(row)).some((row) => textMatchesSisTerm(row.textContent || "", term))) return true;
		if (Array.from(documentRoot.querySelectorAll("[data-current-term], [aria-current='true'], h1, h2, h3, legend, caption")).some((element) => isVisible(element) && compactText(element.textContent).length < 200 && textMatchesSisTerm(element.textContent || "", term))) return true;
		if (Array.from(documentRoot.querySelectorAll("input[id*='TERM'], input[id*='STRM']")).some((field) => isVisible(field) && textMatchesSisTerm(field.value, term))) return true;
		return false;
	}
	function isVisible(element) {
		const html = element;
		const style = getComputedStyle(html);
		return style.display !== "none" && style.visibility !== "hidden" && !html.hidden;
	}
	function controlLabel(element) {
		return element.tagName === "INPUT" ? element.value : compactText(element.textContent);
	}
	function findClickable(root, pattern) {
		return Array.from(root.querySelectorAll("a, button, [role='menuitem'], input[type='button'], input[type='submit']")).find((element) => {
			const label = controlLabel(element);
			return isVisible(element) && pattern.test(label);
		});
	}
	function findControlByIdPrefix(documentRoot, prefix) {
		return Array.from(documentRoot.querySelectorAll("[id]")).find((element) => element.id.startsWith(prefix) && isVisible(element)) ?? null;
	}
	function findRequirementSearchControls(documentRoot) {
		return Array.from(documentRoot.querySelectorAll("[id^='DERIVED_SAA_DPR_SSR_PB_SEARCH$']")).filter((element) => isVisible(element) && !/^hide detail\b/i.test(controlLabel(element)));
	}
	function findRequirementExpansionControls(documentRoot) {
		return Array.from(documentRoot.querySelectorAll("[id^='DERIVED_SAA_DPR_SSR_EXPAND_COLLAPS$']")).filter((element) => {
			if (!isVisible(element)) return false;
			if (element.getAttribute("aria-expanded") === "true") return false;
			const state = compactText([
				element.getAttribute("aria-label"),
				element.getAttribute("title"),
				element.querySelector("img")?.getAttribute("alt"),
				element.querySelector("img")?.getAttribute("title"),
				element.querySelector("img")?.getAttribute("src"),
				element.className,
				element.querySelector("img")?.className
			].filter(Boolean).join(" "));
			return !/collapse|expanded|hide detail/i.test(state);
		});
	}
	function requirementControlIdentity(element) {
		const rowIndex = element.id.match(/\$(\d+)/)?.[1];
		if (rowIndex) {
			const relatedIds = [`DERIVED_SAA_DPR_GROUPBOX1$${rowIndex}`, `DERIVED_SAA_DPR_SAA_REQ_DISP$${rowIndex}$`];
			for (const id of relatedIds) {
				const related = element.ownerDocument.getElementById(id);
				const label = related ? compactText(controlLabel(related)) : "";
				if (label) return label.slice(0, 180).toLowerCase();
			}
		}
		const localLabels = [];
		let current = element.parentElement;
		for (let depth = 0; current && depth < 5; depth += 1, current = current.parentElement) {
			const text = compactText(current.innerText);
			if (text && text.length <= 180) localLabels.push(text);
		}
		const label = localLabels.sort((left, right) => left.length - right.length)[0];
		return label ? label.toLowerCase() : element.id;
	}
	function findEnrollmentAddClasses(documentRoot) {
		return Array.from(documentRoot.querySelectorAll("a[href]")).find((link) => /SSR_SSENRL_CART|Z_HC_SSR_SSENRL_CART_LNK/i.test(link.href) && isVisible(link)) ?? findClickable(documentRoot, /^enrollment add classes$/i);
	}
	function isForbiddenEnrollmentControl(element) {
		const label = controlLabel(element);
		return /finish enrolling|step\s*[23]|submit enrollment|^enroll$/i.test(label);
	}
	function classifySisPage(signals) {
		const text = compactText(signals.text);
		const controlIds = signals.controlIds || [];
		const hasControl = (pattern) => controlIds.some((id) => pattern.test(id));
		if (/session.*expired|sign in to access|Suspension of HKU Portal Services|system.*unavailable|maintenance/i.test(text)) return "blocked";
		if (hasControl(/^DERIVED_SSS_SCT_SSR_PB_GO$/i) && hasControl(/^SSR_DUMMY_RECV1\$sels\$/i)) return "term-selection";
		if (hasControl(/^DERIVED_CLS_DTL_NEXT_PB\$/i)) return "preferences";
		if (hasControl(/^CLASS_SELECT\$/i) || hasControl(/^CLASS_SECTION\$/i)) return "subclass-list";
		if (hasControl(/^DERIVED_SAA_DPR_SSR_EXPAND_COLLAPS\$/i)) return "requirements";
		if (hasControl(/^DERIVED_SAA_DPR_/i) && hasControl(/^CRSE_DESCR\$/i)) return "requirements";
		if (hasControl(/^P_DELETE\$/i) || hasControl(/^DERIVED_REGFRM1_SSR_PB_SRCH$/i)) return "cart";
		if (signals.hasEnrollmentAddClasses && /welcome to the student information system|SIS Home|Student Center/i.test(text)) return "sis-home";
		if (/select.*term/i.test(text) && signals.hasContinue) return "term-selection";
		if (/temporary course list|shopping cart|select classes to add/i.test(text)) return "cart";
		if (/search for classes/i.test(text) && /my requirements/i.test(text)) return "class-search";
		if (/my requirements/i.test(text) && /show detail|requirement group|not satisfied|satisfied/i.test(text)) return "requirements";
		if (/enrollment preferences/i.test(text)) return "preferences";
		if (/course detail/i.test(text) || /class number/i.test(text) && signals.hasSelect) return "course-detail";
		return "unknown";
	}
	function detectSisPage(documentRoot) {
		return classifySisPage({
			text: documentRoot.body?.innerText || "",
			hasContinue: Boolean(findClickable(documentRoot, /^continue$/i)),
			hasEnrollmentAddClasses: Boolean(findEnrollmentAddClasses(documentRoot)),
			hasSelect: Boolean(findClickable(documentRoot, /^select$/i)),
			controlIds: Array.from(documentRoot.querySelectorAll("[id]")).map((element) => element.id)
		});
	}
	function parseCartText(text, expectedCourses = []) {
		const normalized = compactText(text);
		const codeMatch = normalized.match(/\b([A-Z]{4})\s*(\d{4})\b/i);
		const classMatch = normalized.match(/(?:class(?:\s+number|\s+no\.?|\s*#)?\s*[:#]?\s*|\()([0-9]{3,6})\)?/i);
		if (!codeMatch || !classMatch) return null;
		const courseCode = normalizeCourseCode(`${codeMatch[1]}${codeMatch[2]}`);
		const subclassMatch = normalized.slice((codeMatch.index ?? 0) + codeMatch[0].length).match(/(?:^|[-–/]|subclass\s*[:#]?)\s*([0-9][A-Z0-9]{0,3})\b/i);
		const expected = expectedCourses.find((course) => normalizeCourseCode(course.courseCode) === courseCode && course.classNumber === classMatch[1]);
		return {
			courseCode,
			subclass: subclassMatch?.[1].toUpperCase() ?? expected?.subclass.toUpperCase() ?? "UNKNOWN",
			classNumber: classMatch[1]
		};
	}
	function readTemporaryCourseListSnapshot(documentRoot, expectedCourses = []) {
		const found = /* @__PURE__ */ new Map();
		const roots = Array.from(documentRoot.querySelectorAll("table")).filter((table) => /temporary course list|shopping cart|select classes to add/i.test(compactText(table.innerText)));
		const scopedRoots = roots.length ? roots : [documentRoot];
		const anchoredRows = Array.from(documentRoot.querySelectorAll("a[id^='P_CLASS_NAME$']")).map((control) => control.closest("tr")).filter((row) => Boolean(row));
		const rows = anchoredRows.length ? anchoredRows : scopedRoots.flatMap((root) => Array.from(root.querySelectorAll("tr")));
		for (const row of rows) {
			const parsed = parseCartText(row.innerText, expectedCourses);
			if (parsed) found.set(`${parsed.courseCode}|${parsed.subclass}|${parsed.classNumber}`, parsed);
		}
		const courses = [...found.values()];
		const text = compactText(documentRoot.body?.innerText);
		const explicitlyEmpty = /temporary course list.*(?:is empty|no classes)|shopping cart.*(?:is empty|no classes)|you do not have any classes/i.test(text);
		const courseLikeRows = rows.filter((row) => /\b[A-Z]{4}\s*\d{4}\b/i.test(compactText(row.innerText)));
		const allCourseRowsParsed = courseLikeRows.length > 0 && courseLikeRows.length === courses.length;
		return {
			courses,
			confident: Boolean(roots.length && (explicitlyEmpty || allCourseRowsParsed)),
			reason: !roots.length ? "TEMPORARY_COURSE_LIST_REGION_NOT_FOUND" : courseLikeRows.length !== courses.length ? "UNPARSED_COURSE_ROWS" : "EMPTY_CART_NOT_CONFIRMED"
		};
	}
	function findTermChoice(documentRoot, term) {
		const choices = Array.from(documentRoot.querySelectorAll("input[id^='SSR_DUMMY_RECV1$sels$'][type='radio'], input[id^='SSR_DUMMY_RECV1$sels$'][type='checkbox']"));
		for (const choice of choices) {
			const row = choice.closest("tr");
			if (row && textMatchesSisTerm(row.textContent || "", term)) return choice;
			const label = choice.id ? documentRoot.querySelector(`label[for='${CSS.escape(choice.id)}']`) : null;
			if (label && textMatchesSisTerm(label.textContent || "", term)) return choice;
		}
		return null;
	}
	function findCourseInRequirements(documentRoot, target) {
		const code = normalizeCourseCode(target.courseCode);
		const codePattern = new RegExp(`\\b${escapeRegExp(code.slice(0, 4))}\\s*${escapeRegExp(code.slice(4))}\\b`, "i");
		return Array.from(documentRoot.querySelectorAll("a[id^='CRSE_DESCR$']")).find((control) => {
			if (!isVisible(control)) return false;
			const row = control.closest("tr");
			return Boolean(row && codePattern.test(compactText(row.textContent)));
		}) ?? null;
	}
	function findExactSubclass(documentRoot, target) {
		const subclassPattern = new RegExp(`\\b${escapeRegExp(target.subclass)}(?:-[A-Z]+)?\\b`, "i");
		const classNumberPattern = new RegExp(`\\b${escapeRegExp(target.classNumber)}\\b`);
		return Array.from(documentRoot.querySelectorAll("a[id^='CLASS_SELECT$']")).find((select) => {
			if (!isVisible(select) || isForbiddenEnrollmentControl(select)) return false;
			const row = select.closest("tr");
			const text = compactText(row?.textContent);
			return Boolean(row && subclassPattern.test(text) && classNumberPattern.test(text));
		}) ?? null;
	}
	function preferencesMatchTarget(documentRoot, target) {
		const text = compactText(documentRoot.body?.innerText).toUpperCase();
		const code = normalizeCourseCode(target.courseCode);
		const spacedCode = `${code.slice(0, 4)} ${code.slice(4)}`;
		const hasCourse = text.includes(code) || text.includes(spacedCode);
		const hasSubclass = new RegExp(`\\b${escapeRegExp(target.subclass)}\\b`, "i").test(text);
		return hasCourse && hasSubclass;
	}
	function findCartRemoval(documentRoot, target) {
		const row = Array.from(documentRoot.querySelectorAll("tr")).find((candidate) => {
			const parsed = parseCartText(candidate.innerText, [{
				...target,
				title: ""
			}]);
			return parsed && parsed.courseCode === normalizeCourseCode(target.courseCode) && parsed.subclass === target.subclass.toUpperCase() && parsed.classNumber === target.classNumber;
		});
		if (!row) return null;
		return row.querySelector("a[id^='P_DELETE$'], button[id^='P_DELETE$'], input[id^='P_DELETE$']") ?? findClickable(row, /^(delete|remove)$/i);
	}
	//#endregion
	//#region extension/src/overlay.ts
	var HOST_ID = "hku-course-planner-sis-overlay";
	function removeOverlay() {
		document.getElementById(HOST_ID)?.remove();
	}
	function list(label, values) {
		if (!values.length) return "";
		return `<section><h4>${label} <span>${values.length}</span></h4><ul>${values.map((value) => `<li>${value}</li>`).join("")}</ul></section>`;
	}
	function diffMarkup(diff) {
		if (!diff) return "";
		return [
			list("Add", diff.add.map((course) => `${course.courseCode} · ${course.subclass} · ${course.classNumber}`)),
			list("Replace", diff.replace.map(({ target, current }) => `${target.courseCode}: ${current.map((course) => course.subclass).join(", ")} → ${target.subclass}`)),
			list("Remove", diff.remove.map((course) => `${course.courseCode} · ${course.subclass} · ${course.classNumber}`)),
			list("Correct", diff.correct.map((course) => `${course.courseCode} · ${course.subclass}`))
		].join("");
	}
	function termMarkup(progress, active) {
		const resultSummary = progress.results.map((result) => `${result.courseCode} · ${result.status}${result.errorCode ? ` · ${result.errorCode}` : ""}`);
		return `
    <article class="term ${active ? "active" : ""}">
      <div class="term-head"><h3>${progress.term}</h3><span class="term-status status-${progress.status}">${progress.status}</span></div>
      ${diffMarkup(progress.diff)}
      ${resultSummary.length ? `<ul class="results">${resultSummary.map((value) => `<li>${value}</li>`).join("")}</ul>` : ""}
    </article>`;
	}
	function renderOverlay(job, handlers) {
		let host = document.getElementById(HOST_ID);
		if (!host) {
			host = document.createElement("div");
			host.id = HOST_ID;
			document.documentElement.append(host);
		}
		const shadow = host.shadowRoot ?? host.attachShadow({ mode: "open" });
		shadow.innerHTML = `
    <style>
      :host{all:initial}*{box-sizing:border-box}.panel{position:fixed;right:18px;bottom:18px;z-index:2147483647;width:min(430px,calc(100vw - 36px));max-height:calc(100vh - 36px);overflow:auto;padding:18px;border:1px solid #b9c8bc;border-radius:16px;background:#fbfcf9;color:#142019;box-shadow:0 22px 70px rgba(0,0,0,.28);font:13px/1.45 system-ui,sans-serif}.head,.term-head{display:flex;align-items:flex-start;justify-content:space-between;gap:12px}h2,h3,h4{margin:0}h2{color:#0b5b43;font-size:18px}.phase,.term-status{padding:4px 8px;border-radius:999px;background:#e3eee6;color:#0b5b43;font-size:10px;font-weight:800;text-transform:uppercase}p{margin:8px 0 14px;color:#5e6961}.term{margin-top:10px;padding:12px;border:1px solid #dce4dd;border-radius:12px;background:#fff}.term.active{border-color:#0b5b43;box-shadow:inset 0 0 0 1px #0b5b43}.term h3{font-size:13px}.status-complete{background:#dfeee4}.status-failed{background:#f7dfd6;color:#8b351e}.status-pending{background:#edf0ed;color:#69736c}section{padding:8px 0;border-top:1px solid #e8ece8}h4{margin-bottom:4px;font-size:11px}h4 span{color:#738078}ul{margin:0;padding-left:18px;color:#465249;font:10px/1.5 ui-monospace,monospace}.results{margin-top:8px;padding-top:8px;border-top:1px solid #edf0ed}.actions{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:14px}button{min-height:38px;padding:0 12px;border:1px solid #c8d2ca;border-radius:8px;background:white;color:#203028;cursor:pointer;font-weight:750}.safe{margin-top:12px;padding-top:12px;border-top:1px solid #e0e6e1;color:#647169;font-size:10px}
    </style>
    <aside class="panel" role="dialog" aria-label="HKU Course Planner SIS sync">
      <div class="head"><h2>Full-year SIS sync</h2><span class="phase">automatic</span></div>
      <p>${job.message}</p>
      ${job.termProgress.map((progress, index) => termMarkup(progress, index === job.activeTermIndex && job.phase !== "complete")).join("")}
      <div class="actions">
        ${job.phase === "paused" ? `<button id="resume">Resume sync</button>` : job.phase === "complete" ? "" : `<button id="pause">Pause</button>`}
        <button id="cancel">${job.phase === "complete" ? "Close" : "Cancel sync"}</button>
        <button id="diagnostic">Copy diagnostic summary</button>
      </div>
      <div class="safe">Version ${job.extensionVersion}. Temporary Course Lists may be changed automatically. Step 2, Step 3, and formal enrollment controls are never used.</div>
    </aside>`;
		shadow.getElementById("pause")?.addEventListener("click", handlers.pause);
		shadow.getElementById("resume")?.addEventListener("click", handlers.resume);
		shadow.getElementById("cancel")?.addEventListener("click", () => {
			removeOverlay();
			handlers.cancel();
		});
		shadow.getElementById("diagnostic")?.addEventListener("click", () => void navigator.clipboard.writeText(diagnosticSummary(job)));
	}
	//#endregion
	//#region extension/src/sis.ts
	var STALE_NOTICE_ID = "hku-course-planner-stale-extension";
	var PAGE_CLICK_EVENT = "hku-course-planner-page-click";
	var busy = false;
	var automationActive = false;
	var rerunRequested = false;
	var runTimer;
	var nextRunNotBefore = 0;
	var CONTROL_RETRY_DELAY_MS = 3500;
	var MAX_CONTROL_ATTEMPTS = 3;
	function scheduleRun(delay = 300) {
		if (runTimer !== void 0) window.clearTimeout(runTimer);
		const scheduledDelay = Math.max(delay, nextRunNotBefore - Date.now(), 0);
		runTimer = window.setTimeout(() => {
			runTimer = void 0;
			if (busy) {
				rerunRequested = true;
				return;
			}
			run();
		}, scheduledDelay);
	}
	function staleExtensionNotice() {
		removeOverlay();
		if (document.getElementById(STALE_NOTICE_ID)) return;
		const notice = document.createElement("div");
		notice.id = STALE_NOTICE_ID;
		notice.style.cssText = "position:fixed;right:18px;bottom:18px;z-index:2147483647;max-width:360px;padding:14px 16px;border-radius:12px;background:#7a2e18;color:white;font:600 13px/1.45 system-ui;box-shadow:0 12px 36px rgba(0,0,0,.25)";
		notice.textContent = "The HKU Course Planner extension was updated. Reload this SIS page to continue safely.";
		document.documentElement.append(notice);
	}
	async function send(message) {
		try {
			return await chrome.runtime.sendMessage(message);
		} catch (error) {
			staleExtensionNotice();
			throw error;
		}
	}
	async function getJob() {
		return (await send({ type: "GET_JOB" })).job ?? null;
	}
	async function claim(job, page) {
		return send({
			type: "CLAIM_SIS_CONTROLLER",
			jobId: job.plan.jobId,
			page
		});
	}
	async function update(job, patch) {
		const response = await send({
			type: "UPDATE_JOB",
			source: "sis",
			jobId: job.plan.jobId,
			expectedRevision: job.revision,
			patch
		});
		if (!response.ok || !response.job) {
			const error = new Error(response.error || "SIS_JOB_UPDATE_FAILED");
			error.name = response.error || "SIS_JOB_UPDATE_FAILED";
			throw error;
		}
		return response.job;
	}
	function patchActiveProgress(job, patch) {
		return job.termProgress.map((progress, index) => index === job.activeTermIndex ? {
			...progress,
			...patch
		} : progress);
	}
	async function navigateOnce(job, key, element, patch) {
		const sameControl = job.lastMutationKey === key;
		const previousAttempt = sameControl ? job.mutationAttempt ?? 1 : 0;
		const elapsed = Date.now() - (job.lastMutationAt ?? 0);
		if (sameControl && elapsed < CONTROL_RETRY_DELAY_MS) {
			scheduleRun(CONTROL_RETRY_DELAY_MS - elapsed);
			return false;
		}
		if (previousAttempt >= MAX_CONTROL_ATTEMPTS) throw new Error(`SIS_CONTROL_UNRESPONSIVE: ${key} did not navigate after ${MAX_CONTROL_ATTEMPTS} attempts.`);
		if ((await update(job, {
			...patch,
			lastMutationKey: key,
			lastMutationAt: Date.now(),
			mutationAttempt: previousAttempt + 1
		})).lastMutationKey !== key) return false;
		if (element instanceof HTMLAnchorElement && element.href.startsWith("javascript:")) document.dispatchEvent(new CustomEvent(PAGE_CLICK_EVENT, { detail: { id: element.id } }));
		else element.click();
		nextRunNotBefore = Date.now() + 2e3;
		scheduleRun();
		return true;
	}
	function render(job) {
		renderOverlay(job, {
			pause: () => void send({
				type: "PAUSE_JOB",
				jobId: job.plan.jobId
			}).then(() => run()).catch(() => void 0),
			resume: () => void send({
				type: "RESUME_JOB",
				jobId: job.plan.jobId
			}).then(() => run()).catch(() => void 0),
			cancel: () => {
				removeOverlay();
				send({
					type: "CANCEL_JOB",
					jobId: job.plan.jobId
				}).catch(() => void 0);
			}
		});
	}
	async function pause(job, message, errorCode) {
		const progress = activeTermProgress(job);
		render(await update(job, {
			phase: "paused",
			message,
			termProgress: patchActiveProgress(job, {
				status: "failed",
				results: errorCode && job.activeCourseCode ? progress.results.map((result) => result.courseCode === job.activeCourseCode ? {
					...result,
					status: "failed",
					errorCode
				} : result) : progress.results
			}),
			lastMutationKey: void 0,
			lastMutationAt: void 0,
			mutationAttempt: void 0
		}));
	}
	function currentTarget(job) {
		if (job.pendingAction === "rollback") return job.recoveryTarget ?? null;
		if (job.replacementTarget) return job.replacementTarget;
		return activeTermPlan(job).courses.find((course) => course.courseCode === job.activeCourseCode) ?? null;
	}
	async function handleTermSelection(job) {
		const term = activeTermPlan(job).term;
		const choice = findTermChoice(document, term);
		const continueButton = findClickable(document, /^continue$/i);
		if (!choice || !continueButton || isForbiddenEnrollmentControl(continueButton)) {
			await pause(job, `TERM_NOT_FOUND: SIS does not show the exact term ${term}.`, "TERM_NOT_FOUND");
			return;
		}
		if (!choice.checked) choice.click();
		if (!choice.checked) {
			await pause(job, `TERM_NOT_SELECTED: Select ${term}, then resume.`, "TERM_NOT_SELECTED");
			return;
		}
		await navigateOnce(job, `term:${term}`, continueButton, {
			phase: "reading-cart",
			message: `Opening ${term} Temporary Course List.`,
			targetTermConfirmed: true,
			termProgress: patchActiveProgress(job, { status: "syncing" })
		});
	}
	async function recoverToEnrollment(job) {
		const addClasses = findEnrollmentAddClasses(document);
		if (addClasses && !isForbiddenEnrollmentControl(addClasses)) {
			await navigateOnce(job, `recover-add-classes:${activeTermPlan(job).term}:${location.pathname}`, addClasses, {
				phase: "selecting-term",
				message: "Returning to Enrollment Add Classes through visible SIS navigation.",
				targetTermConfirmed: false
			});
			return;
		}
		await pause(job, "ENROLLMENT_ADD_CLASSES_NOT_FOUND: Open Enrollment Add Classes from the SIS menu, then resume.", "ENROLLMENT_ADD_CLASSES_NOT_FOUND");
	}
	async function enforceTargetTerm(job, page) {
		const term = activeTermPlan(job).term;
		if (page === "term-selection") return true;
		if (job.targetTermConfirmed) return true;
		if (pageShowsSisTerm(document, term)) {
			await update(job, { targetTermConfirmed: true });
			scheduleRun(0);
			return false;
		}
		const changeTerm = findClickable(document, /^change term$/i);
		if (changeTerm && !isForbiddenEnrollmentControl(changeTerm)) {
			await navigateOnce(job, `change-term:${term}`, changeTerm, {
				phase: "selecting-term",
				message: `Switching SIS to ${term}.`,
				targetTermConfirmed: false
			});
			return false;
		}
		await recoverToEnrollment(job);
		return false;
	}
	async function startCourseAdd(job, target, pendingAction, retry = false) {
		render(await update(job, {
			phase: "adding",
			message: pendingAction === "rollback" ? `Restoring ${target.courseCode} ${target.subclass} after the replacement failed.` : `Adding ${target.courseCode} ${target.subclass} to ${activeTermPlan(job).term}.`,
			activeCourseCode: target.courseCode,
			pendingAction,
			attemptedRequirementControls: [],
			lastMutationKey: void 0,
			lastMutationAt: void 0,
			mutationAttempt: void 0,
			addAttempt: retry ? (job.addAttempt ?? 1) + 1 : 1
		}));
		scheduleRun(0);
	}
	async function returnToCartForRollback(job, failureMessage, errorCode) {
		if (job.pendingAction === "rollback") {
			await pause(job, `ROLLBACK_FAILED: ${failureMessage}`, "ROLLBACK_FAILED");
			return;
		}
		const backup = job.replacementBackup;
		const replacement = job.replacementTarget;
		if (!backup || !replacement) {
			await pause(job, failureMessage, errorCode);
			return;
		}
		const recoveryTarget = {
			courseCode: backup.courseCode,
			title: replacement.title,
			subclass: backup.subclass,
			classNumber: backup.classNumber
		};
		const next = await update(job, {
			phase: "reading-cart",
			message: `${failureMessage} Restoring ${backup.courseCode} ${backup.subclass}.`,
			activeCourseCode: backup.courseCode,
			pendingAction: "rollback",
			recoveryTarget,
			attemptedRequirementControls: [],
			lastMutationKey: void 0,
			lastMutationAt: void 0,
			mutationAttempt: void 0,
			addAttempt: 0
		});
		const addTab = findClickable(document, /^add$/i);
		if (addTab && !isForbiddenEnrollmentControl(addTab)) {
			await navigateOnce(next, `rollback-return:${backup.courseCode}:${backup.subclass}`, addTab, {
				phase: "reading-cart",
				message: `Returning to the Temporary Course List to restore ${backup.courseCode} ${backup.subclass}.`
			});
			return;
		}
		await pause(next, `ROLLBACK_NAVIGATION_REQUIRED: Return to the Temporary Course List, then resume. Original error: ${failureMessage}`, errorCode);
	}
	function cartContains(cart, target) {
		return cart.some((course) => sameSisCourse(course, target));
	}
	async function deleteCartCourse(job, course, pendingAction) {
		const control = findCartRemoval(document, course);
		if (!control || isForbiddenEnrollmentControl(control)) {
			await pause(job, `CART_DELETE_NOT_FOUND: Could not locate exact ${course.courseCode} ${course.subclass} (${course.classNumber}).`, "CART_DELETE_NOT_FOUND");
			return;
		}
		await navigateOnce(job, `delete:${activeTermPlan(job).term}:${course.courseCode}:${course.subclass}:${course.classNumber}`, control, {
			phase: pendingAction === "replace-remove" ? "replacing" : "removing",
			message: pendingAction === "replace-remove" ? `Removing ${course.courseCode} ${course.subclass} before adding the planned subclass.` : `Removing extra course ${course.courseCode} ${course.subclass}.`,
			activeCartCourse: course,
			pendingAction
		});
	}
	async function advanceOrComplete(job, snapshot, results) {
		const completedProgress = patchActiveProgress(job, {
			status: "complete",
			observedCart: snapshot,
			diff: computeSisSyncDiff(activeTermPlan(job), snapshot),
			results
		});
		if (job.activeTermIndex === 0) {
			render(await update(job, {
				activeTermIndex: 1,
				phase: "selecting-term",
				message: `${activeTermPlan(job).term} is synced. Switching to ${job.plan.terms[1].term}.`,
				termProgress: completedProgress.map((progress, index) => index === 1 ? {
					...progress,
					status: "syncing"
				} : progress),
				activeCourseCode: void 0,
				activeCartCourse: void 0,
				pendingAction: void 0,
				replacementTarget: void 0,
				replacementBackup: void 0,
				recoveryTarget: void 0,
				attemptedRequirementControls: [],
				targetTermConfirmed: false,
				lastMutationKey: void 0,
				lastMutationAt: void 0,
				mutationAttempt: void 0,
				addAttempt: void 0
			}));
			scheduleRun(0);
			return;
		}
		render(await update(job, {
			phase: "complete",
			message: "Sem 1 and Sem 2 Temporary Course Lists match the Planner. Enrollment has not been submitted.",
			termProgress: completedProgress,
			activeCourseCode: void 0,
			activeCartCourse: void 0,
			pendingAction: void 0,
			replacementTarget: void 0,
			replacementBackup: void 0,
			recoveryTarget: void 0,
			lastMutationKey: void 0,
			lastMutationAt: void 0,
			mutationAttempt: void 0,
			addAttempt: void 0
		}));
	}
	async function syncCart(job) {
		const termPlan = activeTermPlan(job);
		const progress = activeTermProgress(job);
		const snapshot = readTemporaryCourseListSnapshot(document, termPlan.courses);
		if (!snapshot.confident) {
			await pause(job, `${snapshot.reason || "CART_PARSE_UNVERIFIED"}: The Temporary Course List could not be read confidently.`, snapshot.reason || "CART_PARSE_UNVERIFIED");
			return;
		}
		const diff = computeSisSyncDiff(termPlan, snapshot.courses);
		if (job.pendingAction === "replace-remove" || job.pendingAction === "remove-extra") {
			if (job.activeCartCourse && cartContains(snapshot.courses, job.activeCartCourse)) {
				if ((job.mutationAttempt ?? 1) < MAX_CONTROL_ATTEMPTS) {
					await deleteCartCourse(job, job.activeCartCourse, job.pendingAction);
					return;
				}
				await pause(job, `DELETE_NOT_CONFIRMED: ${job.activeCartCourse.courseCode} ${job.activeCartCourse.subclass} is still present.`, "DELETE_NOT_CONFIRMED");
				return;
			}
			const next = await update(job, {
				phase: "reading-cart",
				message: "Deletion verified. Recomputing the remaining SIS differences.",
				termProgress: patchActiveProgress(job, {
					status: "syncing",
					observedCart: snapshot.courses,
					diff
				}),
				activeCartCourse: void 0,
				pendingAction: void 0,
				lastMutationKey: void 0,
				lastMutationAt: void 0,
				mutationAttempt: void 0
			});
			scheduleRun(0);
			render(next);
			return;
		}
		if (job.pendingAction === "add" || job.pendingAction === "replace-add") {
			const target = currentTarget(job);
			if (!target || !cartContains(snapshot.courses, target)) {
				if (target && (job.addAttempt ?? 1) < MAX_CONTROL_ATTEMPTS) {
					await startCourseAdd(job, target, job.pendingAction, true);
					return;
				}
				await returnToCartForRollback(job, `ADD_NOT_CONFIRMED: ${target?.courseCode || "Target course"} is not visible in the Temporary Course List.`, "ADD_NOT_CONFIRMED");
				return;
			}
			const completedStatus = job.pendingAction === "replace-add" ? "replaced" : "added";
			const results = reconcileCourseResults(termPlan, progress.results, diff, {
				courseCode: target.courseCode,
				status: completedStatus
			});
			const termFinished = diff.add.length === 0 && diff.replace.length === 0 && diff.remove.length === 0;
			if (termFinished) {
				await advanceOrComplete(job, snapshot.courses, results);
				return;
			}
			const nextTarget = diff.add[0] ?? null;
			const next = await update(job, {
				phase: nextTarget ? "adding" : "reading-cart",
				message: nextTarget ? `${target.courseCode} ${target.subclass} was added and verified. Continuing with ${nextTarget.courseCode} ${nextTarget.subclass}.` : `${target.courseCode} ${target.subclass} was added and verified.`,
				termProgress: patchActiveProgress(job, {
					status: "syncing",
					observedCart: snapshot.courses,
					diff,
					results
				}),
				activeCourseCode: nextTarget?.courseCode,
				pendingAction: nextTarget ? "add" : void 0,
				replacementTarget: void 0,
				replacementBackup: void 0,
				recoveryTarget: void 0,
				attemptedRequirementControls: [],
				lastMutationKey: void 0,
				lastMutationAt: void 0,
				mutationAttempt: void 0,
				addAttempt: nextTarget ? 1 : void 0
			});
			render(next);
			if (nextTarget) {
				await openRequirements(next);
				return;
			}
			scheduleRun(0);
			return;
		}
		if (job.pendingAction === "rollback") {
			const recovery = job.recoveryTarget;
			if (recovery && cartContains(snapshot.courses, recovery)) {
				const results = progress.results.map((result) => result.courseCode === recovery.courseCode ? {
					...result,
					status: "restored",
					errorCode: "REPLACEMENT_FAILED"
				} : result);
				await pause({
					...job,
					termProgress: patchActiveProgress(job, {
						observedCart: snapshot.courses,
						diff,
						results
					})
				}, `REPLACEMENT_FAILED_RESTORED: The planned subclass could not be added. ${recovery.courseCode} ${recovery.subclass} was restored.`);
				return;
			}
			if (!recovery) {
				await pause(job, "ROLLBACK_TARGET_MISSING: The original subclass could not be reconstructed safely.", "ROLLBACK_TARGET_MISSING");
				return;
			}
			if ((job.addAttempt ?? 1) >= MAX_CONTROL_ATTEMPTS) {
				await pause(job, `ROLLBACK_FAILED: ${recovery.courseCode} ${recovery.subclass} could not be restored after ${MAX_CONTROL_ATTEMPTS} attempts.`, "ROLLBACK_FAILED");
				return;
			}
			await startCourseAdd(job, recovery, "rollback", true);
			return;
		}
		const results = reconcileCourseResults(termPlan, progress.results, diff);
		const refreshedProgress = patchActiveProgress(job, {
			status: "syncing",
			observedCart: snapshot.courses,
			diff,
			results
		});
		if (job.replacementTarget) {
			if (cartContains(snapshot.courses, job.replacementTarget)) {
				const replacementResults = reconcileCourseResults(termPlan, results, diff, {
					courseCode: job.replacementTarget.courseCode,
					status: "replaced"
				});
				const next = await update(job, {
					phase: "reading-cart",
					message: `${job.replacementTarget.courseCode} replacement verified.`,
					termProgress: patchActiveProgress(job, {
						status: "syncing",
						observedCart: snapshot.courses,
						diff,
						results: replacementResults
					}),
					activeCourseCode: void 0,
					replacementTarget: void 0,
					replacementBackup: void 0,
					lastMutationKey: void 0,
					lastMutationAt: void 0,
					mutationAttempt: void 0,
					addAttempt: void 0
				});
				scheduleRun(0);
				render(next);
				return;
			}
			const wrong = snapshot.courses.find((course) => course.courseCode === job.replacementTarget?.courseCode);
			if (wrong) {
				await deleteCartCourse({
					...job,
					termProgress: refreshedProgress
				}, wrong, "replace-remove");
				return;
			}
			await startCourseAdd({
				...job,
				termProgress: refreshedProgress
			}, job.replacementTarget, "replace-add");
			return;
		}
		if (diff.replace.length) {
			const replacement = diff.replace[0];
			const next = await update(job, {
				phase: "reading-cart",
				message: `Preparing to replace ${replacement.target.courseCode}.`,
				termProgress: refreshedProgress,
				activeCourseCode: replacement.target.courseCode,
				replacementTarget: replacement.target,
				replacementBackup: replacement.current[0],
				lastMutationKey: void 0,
				lastMutationAt: void 0,
				mutationAttempt: void 0
			});
			scheduleRun(0);
			render(next);
			return;
		}
		if (diff.add.length) {
			await startCourseAdd({
				...job,
				termProgress: refreshedProgress
			}, diff.add[0], "add");
			return;
		}
		if (diff.remove.length) {
			await deleteCartCourse({
				...job,
				termProgress: refreshedProgress
			}, diff.remove[0], "remove-extra");
			return;
		}
		await advanceOrComplete({
			...job,
			termProgress: refreshedProgress
		}, snapshot.courses, results);
	}
	async function openRequirements(job) {
		const search = findControlByIdPrefix(document, "DERIVED_REGFRM1_SSR_PB_SRCH");
		if (!search || isForbiddenEnrollmentControl(search)) {
			await returnToCartForRollback(job, "CLASS_SEARCH_NOT_FOUND: The Temporary Course List does not show its Search control.", "CLASS_SEARCH_NOT_FOUND");
			return;
		}
		await navigateOnce(job, `search:${activeTermPlan(job).term}:${job.activeCourseCode}:${job.pendingAction}`, search, {
			phase: "adding",
			message: `Finding ${job.activeCourseCode} through My Requirements.`
		});
	}
	async function openTargetCourse(job) {
		const target = currentTarget(job);
		if (!target) {
			await returnToCartForRollback(job, "ADD_TARGET_MISSING: The target course is no longer available in this job.", "ADD_TARGET_MISSING");
			return;
		}
		const course = findCourseInRequirements(document, target);
		if (course && !isForbiddenEnrollmentControl(course)) {
			await navigateOnce(job, `course:${activeTermPlan(job).term}:${target.courseCode}:${job.pendingAction}`, course, {
				phase: "adding",
				message: `Opening the exact ${target.courseCode} course entry.`
			});
			return;
		}
		const attempted = new Set(job.attemptedRequirementControls ?? []);
		const expansion = findRequirementExpansionControls(document).find((control) => {
			const controlKey = `expand:${requirementControlIdentity(control)}`;
			const attemptPrefix = `${controlKey}:attempt:`;
			const attemptCount = [...attempted].filter((value) => value.startsWith(attemptPrefix)).length;
			return !attempted.has(controlKey) && attemptCount < 3;
		});
		const search = findRequirementSearchControls(document).find((control) => !attempted.has(`search:${requirementControlIdentity(control)}`));
		const control = expansion ?? search;
		const controlKind = expansion ? "expand" : "search";
		if (!control || isForbiddenEnrollmentControl(control)) {
			await returnToCartForRollback(job, `NOT_IN_REQUIREMENTS: ${target.courseCode} was not found in the available My Requirements groups.`, "NOT_IN_REQUIREMENTS");
			return;
		}
		const controlKey = `${controlKind}:${requirementControlIdentity(control)}`;
		const attemptPrefix = `${controlKey}:attempt:`;
		const attemptNumber = controlKind === "expand" ? [...attempted].filter((value) => value.startsWith(attemptPrefix)).length + 1 : 1;
		const attemptKey = controlKind === "expand" ? `${attemptPrefix}${attemptNumber}` : controlKey;
		await navigateOnce(job, `requirement:${activeTermPlan(job).term}:${target.courseCode}:${controlKey}:${attemptNumber}`, control, {
			phase: "adding",
			message: controlKind === "expand" ? `Expanding another My Requirements detail for ${target.courseCode} (attempt ${attemptNumber} of 3).` : `Checking another My Requirements group for ${target.courseCode}.`,
			attemptedRequirementControls: [...attempted, attemptKey]
		});
	}
	async function selectTargetSubclass(job) {
		const target = currentTarget(job);
		if (!target) {
			await returnToCartForRollback(job, "ADD_TARGET_MISSING: The target course is no longer available in this job.", "ADD_TARGET_MISSING");
			return;
		}
		const select = findExactSubclass(document, target);
		if (!select) {
			await returnToCartForRollback(job, `SUBCLASS_NOT_FOUND: SIS does not show exact subclass ${target.subclass} with class number ${target.classNumber}.`, "SUBCLASS_NOT_FOUND");
			return;
		}
		await navigateOnce(job, `subclass:${activeTermPlan(job).term}:${target.courseCode}:${target.subclass}:${target.classNumber}:${job.pendingAction}`, select, {
			phase: "adding",
			message: `Opening ${target.courseCode} ${target.subclass} (${target.classNumber}).`
		});
	}
	async function submitEnrollmentPreferences(job) {
		const target = currentTarget(job);
		if (!target) {
			await returnToCartForRollback(job, "ADD_TARGET_MISSING: The target course is no longer available in this job.", "ADD_TARGET_MISSING");
			return;
		}
		if (!preferencesMatchTarget(document, target)) {
			await returnToCartForRollback(job, `PREFERENCES_TARGET_MISMATCH: The visible page could not be verified as ${target.courseCode} ${target.subclass}.`, "PREFERENCES_TARGET_MISMATCH");
			return;
		}
		const next = findControlByIdPrefix(document, "DERIVED_CLS_DTL_NEXT_PB$");
		if (!next || isForbiddenEnrollmentControl(next)) {
			await returnToCartForRollback(job, "PREFERENCES_NEXT_NOT_FOUND: The safe Next control is not available.", "PREFERENCES_NEXT_NOT_FOUND");
			return;
		}
		await navigateOnce(job, `add-next:${activeTermPlan(job).term}:${target.courseCode}:${target.subclass}:${target.classNumber}:${job.pendingAction}`, next, {
			phase: "verifying",
			message: `Submitted ${target.courseCode} to the Temporary Course List. Verifying the result.`
		});
	}
	function meaningfulUnknownPage() {
		if (!document.body) return false;
		if (findEnrollmentAddClasses(document)) return true;
		const text = compactText(document.body.innerText);
		return text.length >= 80 && /SIS|student center|enrollment|academic|classes/i.test(text);
	}
	async function run() {
		if (busy) {
			rerunRequested = true;
			return;
		}
		if (!document.body) return;
		busy = true;
		try {
			let job = await getJob();
			if (!job) {
				automationActive = false;
				removeOverlay();
				return;
			}
			automationActive = ![
				"paused",
				"failed",
				"complete",
				"cancelled"
			].includes(job.phase);
			const page = detectSisPage(document);
			if (page === "unknown" && !meaningfulUnknownPage()) {
				removeOverlay();
				return;
			}
			const establishedFlowBeforeClaim = job.targetTermConfirmed && [
				"adding",
				"verifying",
				"replacing",
				"removing",
				"reading-cart"
			].includes(job.phase);
			if (establishedFlowBeforeClaim && (page === "unknown" || page === "sis-home")) {
				removeOverlay();
				return;
			}
			const controller = await claim(job, page);
			if (!controller.granted || !controller.job) {
				removeOverlay();
				return;
			}
			job = controller.job;
			if (job.phase === "cancelled") {
				automationActive = false;
				removeOverlay();
				return;
			}
			if ([
				"paused",
				"failed",
				"complete"
			].includes(job.phase)) {
				automationActive = false;
				render(job);
				return;
			}
			render(job);
			if (page === "blocked") {
				await pause(job, "SIS_SESSION_BLOCKED: Complete login, maintenance, or the displayed security step. No bypass was attempted.", "SIS_SESSION_BLOCKED");
				return;
			}
			const establishedFlow = job.targetTermConfirmed && [
				"adding",
				"verifying",
				"replacing",
				"removing",
				"reading-cart"
			].includes(job.phase);
			if (page === "unknown") {
				if (establishedFlow) {
					render({
						...job,
						message: "Waiting for the current SIS page to finish loading."
					});
					return;
				}
				await recoverToEnrollment(job);
				return;
			}
			if (page === "term-selection") {
				await handleTermSelection(job);
				return;
			}
			if (page === "sis-home") {
				if (establishedFlow) {
					removeOverlay();
					return;
				}
				await recoverToEnrollment(job);
				return;
			}
			if (!await enforceTargetTerm(job, page)) return;
			if (page === "cart") {
				if (job.phase === "adding") await openRequirements(job);
				else await syncCart(job);
				return;
			}
			if (job.phase === "adding" && (page === "class-search" || page === "requirements")) {
				await openTargetCourse(job);
				return;
			}
			if (job.phase === "adding" && page === "subclass-list") {
				await selectTargetSubclass(job);
				return;
			}
			if (job.phase === "adding" && page === "preferences") {
				await submitEnrollmentPreferences(job);
				return;
			}
			await recoverToEnrollment(job);
		} catch (error) {
			if (error instanceof Error && ["REVISION_CONFLICT", "NOT_SIS_CONTROLLER"].includes(error.name)) {
				queueMicrotask(() => void run());
				return;
			}
			try {
				const job = await getJob();
				if (job && !["paused", "cancelled"].includes(job.phase)) await pause(job, `UNEXPECTED_PAGE_STATE: ${error instanceof Error ? error.message : "Unknown error"}`, "UNEXPECTED_PAGE_STATE");
			} catch {}
		} finally {
			busy = false;
			if (rerunRequested) {
				rerunRequested = false;
				queueMicrotask(() => void run());
			}
		}
	}
	chrome.runtime.onMessage.addListener((message) => {
		if (message.type !== "RUN_SIS_JOB") return;
		scheduleRun(0);
	});
	new MutationObserver(() => {
		if (automationActive) scheduleRun();
	}).observe(document.documentElement, {
		childList: true,
		subtree: true
	});
	scheduleRun();
	//#endregion
})();
