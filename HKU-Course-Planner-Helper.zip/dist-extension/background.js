(function() {
	var SIS_SYNC_TERMS = ["2026-27 Sem 1", "2026-27 Sem 2"];
	function normalizeCourseCode(value) {
		return value.toUpperCase().replace(/\s+/g, "").trim();
	}
	function isRecord(value) {
		return Boolean(value) && typeof value === "object" && !Array.isArray(value);
	}
	function cleanString(value) {
		return typeof value === "string" ? value.trim() : "";
	}
	function validateSisSyncPlan(input) {
		const errors = [];
		if (!isRecord(input)) return {
			ok: false,
			errors: ["Sync plan must be an object."]
		};
		const jobId = cleanString(input.jobId);
		const academicYear = cleanString(input.academicYear);
		const term = cleanString(input.term);
		const career = cleanString(input.career);
		const rawCourses = Array.isArray(input.courses) ? input.courses : [];
		if (input.protocolVersion !== 1) errors.push("Unsupported sync protocol version.");
		if (!jobId) errors.push("A job ID is required.");
		if (!academicYear) errors.push("Academic year is required.");
		if (!SIS_SYNC_TERMS.includes(term)) errors.push("Unsupported target term.");
		if (term && academicYear && !term.startsWith(academicYear)) errors.push("Academic year does not match the target term.");
		if (career !== "UG") errors.push("Only the UG career is supported.");
		if (rawCourses.length < 1 || rawCourses.length > 6) errors.push("A sync plan must contain between one and six courses.");
		const courses = [];
		const courseCodes = /* @__PURE__ */ new Set();
		for (const [index, rawCourse] of rawCourses.entries()) {
			if (!isRecord(rawCourse)) {
				errors.push(`Course ${index + 1} is invalid.`);
				continue;
			}
			const courseCode = normalizeCourseCode(cleanString(rawCourse.courseCode));
			const title = cleanString(rawCourse.title);
			const subclass = cleanString(rawCourse.subclass).toUpperCase();
			const classNumber = cleanString(rawCourse.classNumber);
			if (!courseCode || !title || !subclass || !classNumber) {
				errors.push(`Course ${index + 1} is missing code, title, subclass, or class number.`);
				continue;
			}
			if (courseCodes.has(courseCode)) {
				errors.push(`Duplicate course ${courseCode}.`);
				continue;
			}
			courseCodes.add(courseCode);
			courses.push({
				courseCode,
				title,
				subclass,
				classNumber
			});
		}
		if (errors.length) return {
			ok: false,
			errors
		};
		return {
			ok: true,
			value: {
				protocolVersion: 1,
				jobId,
				academicYear,
				term,
				career: "UG",
				courses
			}
		};
	}
	function validateSisFullYearSyncPlan(input) {
		if (!isRecord(input)) return {
			ok: false,
			errors: ["Sync plan must be an object."]
		};
		const jobId = cleanString(input.jobId);
		const academicYear = cleanString(input.academicYear);
		const career = cleanString(input.career);
		const rawTerms = Array.isArray(input.terms) ? input.terms : [];
		const errors = [];
		if (input.protocolVersion !== 2) errors.push("Unsupported full-year sync protocol version.");
		if (!jobId) errors.push("A job ID is required.");
		if (!academicYear) errors.push("Academic year is required.");
		if (career !== "UG") errors.push("Only the UG career is supported.");
		if (rawTerms.length !== SIS_SYNC_TERMS.length) errors.push("A full-year sync plan must contain Sem 1 and Sem 2 exactly once.");
		const terms = [];
		for (const [index, rawTerm] of rawTerms.entries()) {
			if (!isRecord(rawTerm)) {
				errors.push(`Term ${index + 1} is invalid.`);
				continue;
			}
			const term = cleanString(rawTerm.term);
			const validation = validateSisSyncPlan({
				protocolVersion: 1,
				jobId,
				academicYear,
				career,
				term,
				courses: rawTerm.courses
			});
			if (!validation.ok) {
				errors.push(...validation.errors.map((error) => `${term || `Term ${index + 1}`}: ${error}`));
				continue;
			}
			terms.push({
				term: validation.value.term,
				courses: validation.value.courses
			});
		}
		const termNames = terms.map((term) => term.term);
		if (new Set(termNames).size !== termNames.length) errors.push("A full-year sync plan cannot contain duplicate terms.");
		for (const required of SIS_SYNC_TERMS) if (!termNames.includes(required)) errors.push(`Missing ${required}.`);
		if (errors.length) return {
			ok: false,
			errors
		};
		return {
			ok: true,
			value: {
				protocolVersion: 2,
				jobId,
				academicYear,
				career: "UG",
				terms: SIS_SYNC_TERMS.map((term) => terms.find((candidate) => candidate.term === term))
			}
		};
	}
	//#endregion
	//#region extension/src/job.ts
	var JOB_STORAGE_KEY = "sisSyncJobV2";
	var SIS_CONTROLLER_STORAGE_KEY = "sisSyncControllerV1";
	var EXTENSION_RUNTIME_VERSION = "0.4.0";
	function isActionableSisPage(page) {
		return !["unknown", "sis-home"].includes(page);
	}
	function canClaimSisController(existing, candidate, now, leaseMs) {
		if (!existing || existing.jobId !== candidate.jobId) return true;
		if (existing.tabId === candidate.tabId && existing.frameId === candidate.frameId) return true;
		if (existing.tabId === candidate.tabId && !isActionableSisPage(existing.page) && isActionableSisPage(candidate.page)) return true;
		if (isActionableSisPage(existing.page) && !isActionableSisPage(candidate.page)) return false;
		return now - existing.claimedAt > leaseMs;
	}
	function createSisSyncJob(plan) {
		return {
			extensionVersion: EXTENSION_RUNTIME_VERSION,
			mode: "full-year-sync",
			plan,
			phase: "waiting-for-user-page",
			message: "Starting full-year Temporary Course List sync in the SIS tab opened by the user.",
			activeTermIndex: 0,
			termProgress: plan.terms.map((term) => ({
				term: term.term,
				status: "pending",
				results: term.courses.map((course) => ({
					courseCode: course.courseCode,
					status: "pending"
				}))
			})),
			checkpoint: 0,
			revision: 0,
			updatedAt: (/* @__PURE__ */ new Date()).toISOString()
		};
	}
	//#endregion
	//#region extension/src/background.ts
	var CONTROLLER_LEASE_MS = 2500;
	var PLANNER_URL_PREFIX = "https://hku-planner.mjxw05.chatgpt.site/";
	var SIS_DIAGNOSTIC_ENABLED_KEY = "sisDiagnosticCaptureEnabledV1";
	var SIS_DIAGNOSTIC_EVENTS_KEY = "sisDiagnosticCaptureEventsV1";
	var MAX_DIAGNOSTIC_EVENTS = 40;
	var diagnosticWrite = Promise.resolve();
	async function getDiagnosticState() {
		const stored = await chrome.storage.session.get(SIS_DIAGNOSTIC_ENABLED_KEY);
		const eventStore = await chrome.storage.session.get(SIS_DIAGNOSTIC_EVENTS_KEY);
		const events = Array.isArray(eventStore[SIS_DIAGNOSTIC_EVENTS_KEY]) ? eventStore[SIS_DIAGNOSTIC_EVENTS_KEY] : [];
		return {
			enabled: stored[SIS_DIAGNOSTIC_ENABLED_KEY] === true,
			events
		};
	}
	function storeDiagnosticEvent(event, sender) {
		diagnosticWrite = diagnosticWrite.then(async () => {
			if (!sender.tab?.url?.startsWith("https://sis-main.hku.hk/")) return;
			const state = await getDiagnosticState();
			if (!state.enabled) return;
			const enriched = {
				...event,
				frameId: sender.frameId ?? null,
				documentIdPresent: Boolean(sender.documentId)
			};
			if (JSON.stringify(enriched).length > 1e4) return;
			await chrome.storage.session.set({ [SIS_DIAGNOSTIC_EVENTS_KEY]: [...state.events, enriched].slice(-MAX_DIAGNOSTIC_EVENTS) });
		});
		return diagnosticWrite;
	}
	async function broadcastDiagnosticMode(tabId, enabled, count) {
		if (tabId === void 0) return;
		try {
			await chrome.tabs.sendMessage(tabId, {
				type: "SIS_DIAGNOSTIC_MODE",
				enabled,
				count
			});
		} catch {}
	}
	async function getJob() {
		const job = (await chrome.storage.session.get(JOB_STORAGE_KEY))[JOB_STORAGE_KEY];
		if (!job) return null;
		if (job.extensionVersion !== "0.4.0" || job.mode !== "full-year-sync" || !Number.isInteger(job.revision)) {
			await chrome.storage.session.remove(JOB_STORAGE_KEY);
			await chrome.storage.session.remove(SIS_CONTROLLER_STORAGE_KEY);
			return null;
		}
		return job;
	}
	async function saveJob(job, advance = true) {
		const next = {
			...job,
			checkpoint: advance ? job.checkpoint + 1 : job.checkpoint,
			revision: advance ? job.revision + 1 : job.revision,
			updatedAt: (/* @__PURE__ */ new Date()).toISOString()
		};
		await chrome.storage.session.set({ [JOB_STORAGE_KEY]: next });
		return next;
	}
	async function getController() {
		return (await chrome.storage.session.get("sisSyncControllerV1"))["sisSyncControllerV1"] ?? null;
	}
	async function saveController(controller) {
		await chrome.storage.session.set({ [SIS_CONTROLLER_STORAGE_KEY]: controller });
	}
	async function clearController() {
		await chrome.storage.session.remove(SIS_CONTROLLER_STORAGE_KEY);
	}
	function senderIdentity(sender) {
		if (sender.tab?.id === void 0 || sender.frameId === void 0) return null;
		return {
			tabId: sender.tab.id,
			frameId: sender.frameId,
			documentId: sender.documentId
		};
	}
	function controllerMatches(controller, sender) {
		const identity = senderIdentity(sender);
		if (!controller || !identity) return false;
		return controller.tabId === identity.tabId && controller.frameId === identity.frameId && (!controller.documentId || !identity.documentId || controller.documentId === identity.documentId);
	}
	function sanitizeJobPatch(patch) {
		const safe = {};
		for (const key of [
			"phase",
			"message",
			"activeTermIndex",
			"termProgress",
			"activeCourseCode",
			"activeCartCourse",
			"pendingAction",
			"replacementTarget",
			"replacementBackup",
			"recoveryTarget",
			"attemptedRequirementControls",
			"targetTermConfirmed",
			"lastMutationKey",
			"lastMutationAt",
			"mutationAttempt",
			"addAttempt",
			"lastDetectedPage",
			"lastDetectedUrl"
		]) if (key in patch) Object.assign(safe, { [key]: patch[key] });
		return safe;
	}
	async function findExistingSis(senderTab) {
		const sisTabs = await chrome.tabs.query({ url: "https://sis-main.hku.hk/*" });
		return sisTabs.find((tab) => !senderTab?.windowId || tab.windowId === senderTab.windowId) ?? sisTabs[0] ?? null;
	}
	async function focusSis(tab) {
		if (tab.id === void 0) return false;
		await chrome.tabs.update(tab.id, { active: true });
		if (tab.windowId !== void 0) await chrome.windows.update(tab.windowId, { focused: true });
		return true;
	}
	async function startSync(plan, senderTab) {
		const validation = validateSisFullYearSyncPlan(plan);
		if (!validation.ok) return {
			ok: false,
			errors: validation.errors
		};
		const current = await getJob();
		if (current && ![
			"complete",
			"cancelled",
			"failed"
		].includes(current.phase) && current.plan.jobId !== validation.value.jobId) return {
			ok: false,
			errors: ["Another SIS sync is already active in this Chrome session."]
		};
		const sisTab = await findExistingSis(senderTab);
		if (!sisTab?.id) return {
			ok: false,
			errors: ["Open and sign in to HKU SIS in this Chrome window before starting the sync."]
		};
		await clearController();
		const job = await saveJob(createSisSyncJob(validation.value), false);
		await focusSis(sisTab);
		try {
			await chrome.tabs.sendMessage(sisTab.id, { type: "RUN_SIS_JOB" });
		} catch {
			return {
				ok: false,
				errors: [(await saveJob({
					...job,
					phase: "paused",
					message: "SIS_SCRIPT_NOT_READY: Reload the open SIS tab, then start the sync again."
				})).message]
			};
		}
		return {
			ok: true,
			jobId: job.plan.jobId,
			extensionVersion: EXTENSION_RUNTIME_VERSION,
			mode: job.mode
		};
	}
	chrome.runtime.onConnect.addListener((port) => {
		if (port.name !== "hku-course-planner-bridge-v1") return;
		if (!port.sender?.tab?.url?.startsWith(PLANNER_URL_PREFIX)) return;
		port.onMessage.addListener((envelope) => {
			if (envelope?.type !== "PLANNER_PORT_REQUEST" || typeof envelope.requestId !== "string") return;
			const message = envelope.message && typeof envelope.message === "object" ? envelope.message : {};
			(async () => {
				const response = message.type === "START_SYNC" ? await startSync(message.plan, port.sender?.tab) : message.type === "PING" ? {
					ok: true,
					extensionVersion: EXTENSION_RUNTIME_VERSION,
					mode: "full-year-sync",
					job: await getJob()
				} : {
					ok: false,
					error: "UNKNOWN_PLANNER_PORT_MESSAGE"
				};
				port.postMessage({
					type: "PLANNER_PORT_RESPONSE",
					requestId: envelope.requestId,
					response
				});
			})().catch((error) => {
				try {
					port.postMessage({
						type: "PLANNER_PORT_RESPONSE",
						requestId: envelope.requestId,
						response: {
							ok: false,
							error: error instanceof Error ? error.message : "Unexpected extension error."
						}
					});
				} catch {}
			});
		});
	});
	chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
		(async () => {
			if (message?.type === "GET_SIS_DIAGNOSTIC") {
				const state = await getDiagnosticState();
				sendResponse({
					ok: true,
					enabled: state.enabled,
					count: state.events.length
				});
				return;
			}
			if (message?.type === "START_SIS_DIAGNOSTIC" || message?.type === "STOP_SIS_DIAGNOSTIC") {
				const enabled = message.type === "START_SIS_DIAGNOSTIC";
				await chrome.storage.session.set({ [SIS_DIAGNOSTIC_ENABLED_KEY]: enabled });
				const state = await getDiagnosticState();
				await broadcastDiagnosticMode(sender.tab?.id, enabled, state.events.length);
				sendResponse({
					ok: true,
					enabled,
					count: state.events.length
				});
				return;
			}
			if (message?.type === "SIS_DIAGNOSTIC_EVENT") {
				const event = message.event && typeof message.event === "object" ? message.event : null;
				if (!event) {
					sendResponse({
						ok: false,
						error: "INVALID_DIAGNOSTIC_EVENT"
					});
					return;
				}
				await storeDiagnosticEvent(event, sender);
				const state = await getDiagnosticState();
				sendResponse({
					ok: true,
					enabled: state.enabled,
					count: state.events.length
				});
				return;
			}
			if (message?.type === "EXPORT_SIS_DIAGNOSTIC") {
				const state = await getDiagnosticState();
				sendResponse({
					ok: true,
					enabled: state.enabled,
					count: state.events.length,
					json: JSON.stringify({
						protocolVersion: 1,
						kind: "sis-diagnostic-click-capture",
						exportedAt: (/* @__PURE__ */ new Date()).toISOString(),
						events: state.events
					}, null, 2)
				});
				return;
			}
			if (message?.type === "CLEAR_SIS_DIAGNOSTIC") {
				await chrome.storage.session.remove(SIS_DIAGNOSTIC_EVENTS_KEY);
				sendResponse({
					ok: true,
					enabled: (await getDiagnosticState()).enabled,
					count: 0
				});
				return;
			}
			if (message?.type === "START_SYNC") {
				sendResponse(await startSync(message.plan, sender.tab));
				return;
			}
			if (message?.type === "GET_JOB") {
				sendResponse({
					ok: true,
					job: await getJob(),
					extensionVersion: EXTENSION_RUNTIME_VERSION
				});
				return;
			}
			if (message?.type === "CLAIM_SIS_CONTROLLER") {
				const current = await getJob();
				const identity = senderIdentity(sender);
				if (!current || current.plan.jobId !== message.jobId || !identity) {
					sendResponse({
						ok: false,
						granted: false,
						error: "JOB_OR_FRAME_NOT_FOUND"
					});
					return;
				}
				const existing = await getController();
				const now = Date.now();
				const candidate = {
					jobId: current.plan.jobId,
					...identity,
					page: typeof message.page === "string" ? message.page : "unknown",
					claimedAt: now
				};
				const expectedPageTransition = existing?.tabId === candidate.tabId && (current.phase === "selecting-term" && candidate.page === "term-selection" || current.phase === "reading-cart" && candidate.page === "cart");
				if (!expectedPageTransition && !canClaimSisController(existing, candidate, now, CONTROLLER_LEASE_MS)) {
					sendResponse({
						ok: true,
						granted: false,
						job: current
					});
					return;
				}
				await saveController(candidate);
				const detectedUrl = sender.tab?.url || "";
				const detectedPage = candidate.page;
				sendResponse({
					ok: true,
					granted: true,
					job: current.lastDetectedPage === detectedPage && current.lastDetectedUrl === detectedUrl ? current : await saveJob({
						...current,
						lastDetectedPage: detectedPage,
						lastDetectedUrl: detectedUrl
					}),
					extensionVersion: EXTENSION_RUNTIME_VERSION
				});
				return;
			}
			if (message?.type === "UPDATE_JOB") {
				const current = await getJob();
				if (!current || current.plan.jobId !== message.jobId) {
					sendResponse({
						ok: false,
						error: "JOB_NOT_FOUND"
					});
					return;
				}
				if (message.source === "sis" && !controllerMatches(await getController(), sender)) {
					sendResponse({
						ok: false,
						error: "NOT_SIS_CONTROLLER",
						job: current
					});
					return;
				}
				if (message.expectedRevision !== current.revision) {
					sendResponse({
						ok: false,
						error: "REVISION_CONFLICT",
						job: current
					});
					return;
				}
				const patch = message.patch && typeof message.patch === "object" ? message.patch : {};
				sendResponse({
					ok: true,
					job: await saveJob({
						...current,
						...sanitizeJobPatch(patch)
					})
				});
				return;
			}
			if (message?.type === "PAUSE_JOB" || message?.type === "RESUME_JOB") {
				const current = await getJob();
				if (!current || current.plan.jobId !== message.jobId) {
					sendResponse({
						ok: false,
						error: "JOB_NOT_FOUND"
					});
					return;
				}
				const paused = message.type === "PAUSE_JOB";
				const next = await saveJob({
					...current,
					phase: paused ? "paused" : "waiting-for-user-page",
					message: paused ? "Sync paused by the user." : "Resuming in the SIS tab opened by the user.",
					lastMutationKey: void 0
				});
				await clearController();
				const sisTab = paused ? null : await findExistingSis(sender.tab);
				if (!paused && (!sisTab || !await focusSis(sisTab))) {
					sendResponse({
						ok: false,
						error: "SIS_TAB_NOT_FOUND",
						job: await saveJob({
							...next,
							phase: "paused",
							message: "SIS_TAB_NOT_FOUND: Open HKU SIS, then resume."
						})
					});
					return;
				}
				if (!paused && sisTab?.id !== void 0) await chrome.tabs.sendMessage(sisTab.id, { type: "RUN_SIS_JOB" });
				sendResponse({
					ok: true,
					job: next
				});
				return;
			}
			if (message?.type === "CANCEL_JOB") {
				const current = await getJob();
				if (current && current.plan.jobId === message.jobId) await saveJob({
					...current,
					phase: "cancelled",
					message: "Sync cancelled. No further SIS changes will be made."
				});
				await clearController();
				sendResponse({ ok: true });
				return;
			}
			if (message?.type === "CLEAR_FINISHED_JOB") {
				const current = await getJob();
				if (current && [
					"complete",
					"cancelled",
					"failed"
				].includes(current.phase)) {
					await chrome.storage.session.remove(JOB_STORAGE_KEY);
					await clearController();
				}
				sendResponse({ ok: true });
				return;
			}
			sendResponse({
				ok: false,
				error: "UNKNOWN_MESSAGE"
			});
		})().catch((error) => {
			sendResponse({
				ok: false,
				error: error instanceof Error ? error.message : "Unexpected extension error."
			});
		});
		return true;
	});
	//#endregion
})();
