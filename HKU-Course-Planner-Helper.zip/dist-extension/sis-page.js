(function() {
	//#region extension/src/sis-page.ts
	var CLICK_EVENT = "hku-course-planner-page-click";
	var SAFE_CONTROL_PREFIXES = [
		"DERIVED_SSS_SCT_SSS_TERM_LINK",
		"SSR_DUMMY_RECV1$sels$",
		"DERIVED_SSS_SCT_SSR_PB_GO",
		"DERIVED_REGFRM1_SSR_PB_SRCH",
		"DERIVED_SAA_DPR_SSR_PB_SEARCH$",
		"DERIVED_SAA_DPR_SSR_EXPAND_COLLAPS$",
		"CRSE_DESCR$",
		"CLASS_SELECT$",
		"DERIVED_CLS_DTL_NEXT_PB$",
		"P_DELETE$"
	];
	function isSafeControl(element) {
		if (!SAFE_CONTROL_PREFIXES.some((prefix) => element.id.startsWith(prefix))) return false;
		const label = element instanceof HTMLInputElement ? element.value : element.textContent || "";
		return !/finish enrolling|step\s*[23]|submit enrollment|^\s*enroll\s*$/i.test(label);
	}
	document.addEventListener(CLICK_EVENT, (event) => {
		const detail = event instanceof CustomEvent ? event.detail : null;
		const id = detail && typeof detail.id === "string" ? detail.id : "";
		if (!id) return;
		const element = document.getElementById(id);
		if (!(element instanceof HTMLElement) || !isSafeControl(element)) return;
		element.click();
	});
	//#endregion
})();
