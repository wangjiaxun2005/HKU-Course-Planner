(function() {
	//#region extension/src/sis-dom.ts
	function compactText(value) {
		return (value || "").replace(/\s+/g, " ").trim();
	}
	function isVisible(element) {
		const html = element;
		const style = getComputedStyle(html);
		return style.display !== "none" && style.visibility !== "hidden" && !html.hidden;
	}
	function controlLabel(element) {
		return element.tagName === "INPUT" ? element.value : compactText(element.textContent);
	}
	function findClickable(root, pattern) {
		return Array.from(root.querySelectorAll("a, button, [role='menuitem'], input[type='button'], input[type='submit']")).find((element) => {
			const label = controlLabel(element);
			return isVisible(element) && pattern.test(label);
		});
	}
	function findEnrollmentAddClasses(documentRoot) {
		return Array.from(documentRoot.querySelectorAll("a[href]")).find((link) => /SSR_SSENRL_CART|Z_HC_SSR_SSENRL_CART_LNK/i.test(link.href) && isVisible(link)) ?? findClickable(documentRoot, /^enrollment add classes$/i);
	}
	function classifySisPage(signals) {
		const text = compactText(signals.text);
		const controlIds = signals.controlIds || [];
		const hasControl = (pattern) => controlIds.some((id) => pattern.test(id));
		if (/session.*expired|sign in to access|Suspension of HKU Portal Services|system.*unavailable|maintenance/i.test(text)) return "blocked";
		if (hasControl(/^DERIVED_SSS_SCT_SSR_PB_GO$/i) && hasControl(/^SSR_DUMMY_RECV1\$sels\$/i)) return "term-selection";
		if (hasControl(/^DERIVED_CLS_DTL_NEXT_PB\$/i)) return "preferences";
		if (hasControl(/^CLASS_SELECT\$/i) || hasControl(/^CLASS_SECTION\$/i)) return "subclass-list";
		if (hasControl(/^DERIVED_SAA_DPR_SSR_EXPAND_COLLAPS\$/i)) return "requirements";
		if (hasControl(/^DERIVED_SAA_DPR_/i) && hasControl(/^CRSE_DESCR\$/i)) return "requirements";
		if (hasControl(/^P_DELETE\$/i) || hasControl(/^DERIVED_REGFRM1_SSR_PB_SRCH$/i)) return "cart";
		if (signals.hasEnrollmentAddClasses && /welcome to the student information system|SIS Home|Student Center/i.test(text)) return "sis-home";
		if (/select.*term/i.test(text) && signals.hasContinue) return "term-selection";
		if (/temporary course list|shopping cart|select classes to add/i.test(text)) return "cart";
		if (/search for classes/i.test(text) && /my requirements/i.test(text)) return "class-search";
		if (/my requirements/i.test(text) && /show detail|requirement group|not satisfied|satisfied/i.test(text)) return "requirements";
		if (/enrollment preferences/i.test(text)) return "preferences";
		if (/course detail/i.test(text) || /class number/i.test(text) && signals.hasSelect) return "course-detail";
		return "unknown";
	}
	function detectSisPage(documentRoot) {
		return classifySisPage({
			text: documentRoot.body?.innerText || "",
			hasContinue: Boolean(findClickable(documentRoot, /^continue$/i)),
			hasEnrollmentAddClasses: Boolean(findEnrollmentAddClasses(documentRoot)),
			hasSelect: Boolean(findClickable(documentRoot, /^select$/i)),
			controlIds: Array.from(documentRoot.querySelectorAll("[id]")).map((element) => element.id)
		});
	}
	//#endregion
	//#region extension/src/recorder-map.ts
	var CONTROL_RULES = [
		{
			id: "term-row",
			pattern: /SSR_DUMMY_RECV1\$sels\$1\$\$\d+/i,
			role: "select-term-by-row-text",
			safety: "navigation",
			pageBefore: "term-selection",
			pageAfter: "term-selection",
			selectorTemplate: "input[id^='SSR_DUMMY_RECV1$sels$1$$'] within the row matching the exact term"
		},
		{
			id: "term-continue",
			pattern: /DERIVED_SSS_SCT_SSR_PB_GO/i,
			role: "continue-from-term-selection",
			safety: "navigation",
			pageBefore: "term-selection",
			pageAfter: "temporary-course-list",
			selectorTemplate: "#DERIVED_SSS_SCT_SSR_PB_GO"
		},
		{
			id: "cart-delete",
			pattern: /P_DELETE\$\d+/i,
			role: "delete-cart-row",
			safety: "potential-write",
			pageBefore: "temporary-course-list",
			pageAfter: "temporary-course-list",
			selectorTemplate: "a[id^='P_DELETE$'] within the exact cart course row"
		},
		{
			id: "cart-search",
			pattern: /DERIVED_REGFRM1_SSR_PB_SRCH/i,
			role: "open-class-search",
			safety: "navigation",
			pageBefore: "temporary-course-list",
			pageAfter: "class-search",
			selectorTemplate: "#DERIVED_REGFRM1_SSR_PB_SRCH"
		},
		{
			id: "requirement-search",
			pattern: /DERIVED_SAA_DPR_SSR_PB_SEARCH\$\d+/i,
			role: "open-requirement-course-list",
			safety: "navigation",
			pageBefore: "class-search",
			pageAfter: "requirements-course-list",
			selectorTemplate: "[id^='DERIVED_SAA_DPR_SSR_PB_SEARCH$'] within the selected requirement group"
		},
		{
			id: "course-description",
			pattern: /CRSE_DESCR\$\d+/i,
			role: "open-course-by-code",
			safety: "navigation",
			pageBefore: "requirements-course-list",
			pageAfter: "subclass-list",
			selectorTemplate: "[id^='CRSE_DESCR$'] within the row matching the exact course code"
		},
		{
			id: "class-select",
			pattern: /CLASS_SELECT\$\d+/i,
			role: "select-subclass-by-class-number",
			safety: "navigation",
			pageBefore: "subclass-list",
			pageAfter: "class-details",
			selectorTemplate: "[id^='CLASS_SELECT$'] within the row matching subclass and class number"
		},
		{
			id: "class-detail-next",
			pattern: /DERIVED_CLS_DTL_NEXT_PB\$\d+\$/i,
			role: "continue-to-enrollment-preferences",
			safety: "navigation",
			pageBefore: "class-details",
			pageAfter: "enrollment-preferences",
			selectorTemplate: "[id^='DERIVED_CLS_DTL_NEXT_PB$']"
		}
	];
	function describeSisControl(evidenceValues) {
		const evidence = evidenceValues.map((value) => value.replace(/\\/g, "")).join(" ");
		const rule = CONTROL_RULES.find((candidate) => candidate.pattern.test(evidence));
		return rule ? {
			role: rule.role,
			safety: rule.safety,
			selectorTemplate: rule.selectorTemplate
		} : null;
	}
	//#endregion
	//#region extension/src/sis-explorer.ts
	var HOST_ID = "hku-course-planner-diagnostic-capture";
	var MAX_NEARBY_TEXT = 180;
	var captureEnabled = false;
	var capturedEventCount = 0;
	function sanitize(value, limit = 180) {
		return (value || "").replace(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi, "<redacted-email>").replace(/\b\d{7,}\b/g, "<redacted-id>").replace(/\s+/g, " ").trim().slice(0, limit);
	}
	function safePath(value) {
		if (!value) return null;
		try {
			const url = new URL(value, location.href);
			return `${url.origin}${url.pathname}`;
		} catch {
			return null;
		}
	}
	function technicalValue(value) {
		return sanitize(value).replace(/\$\d+/g, "$<row>") || null;
	}
	function rowIndexFor(element) {
		return (element.id || element.getAttribute("name") || "").match(/\$(\d+)/)?.[1] || null;
	}
	function requirementLabels(element) {
		const rowIndex = rowIndexFor(element);
		if (!rowIndex) return [];
		return [
			`DERIVED_SAA_DPR_GROUPBOX1$${rowIndex}`,
			`DERIVED_SAA_DPR_SAA_REQ_DISP$${rowIndex}$`,
			`DERIVED_SAA_DPR_DESCR$${rowIndex}`
		].flatMap((id) => {
			const text = sanitize(element.ownerDocument.getElementById(id)?.textContent, 260);
			return text ? [{
				id: technicalValue(id),
				text
			}] : [];
		});
	}
	function ancestorTrail(element) {
		const trail = [];
		let current = element;
		for (let depth = 0; current && depth < 6; depth += 1, current = current.parentElement) {
			const text = sanitize(current.textContent, 320) || null;
			trail.push({
				tag: current.tagName.toLowerCase(),
				id: technicalValue(current.id),
				text
			});
		}
		return trail;
	}
	function labelFor(element) {
		return sanitize(element.getAttribute("aria-label") || element.getAttribute("title") || (element instanceof HTMLInputElement ? element.value : "") || (element instanceof HTMLImageElement ? element.alt : ""), 100) || null;
	}
	function nearbyText(element) {
		return sanitize((element.closest("tr, li, fieldset, section, form, div") || element.parentElement)?.textContent, MAX_NEARBY_TEXT) || null;
	}
	function imageEvidence(element) {
		const image = element instanceof HTMLImageElement ? element : element.querySelector("img");
		if (!image) return null;
		return {
			src: safePath(image.src),
			alt: sanitize(image.alt, 100) || null,
			title: sanitize(image.title, 100) || null
		};
	}
	function controlEvidence(element) {
		const id = technicalValue(element.id);
		const name = technicalValue(element.getAttribute("name"));
		const label = labelFor(element);
		const description = describeSisControl([
			id || "",
			name || "",
			label || ""
		]);
		const form = element.closest("form");
		return {
			tag: element.tagName.toLowerCase(),
			type: element.getAttribute("type") || null,
			id,
			name,
			rowIndex: rowIndexFor(element),
			role: element.getAttribute("role") || description?.role || null,
			safety: description?.safety || "unknown",
			href: element instanceof HTMLAnchorElement ? safePath(element.href) : null,
			label,
			ariaExpanded: element.getAttribute("aria-expanded"),
			disabled: element.matches(":disabled, [aria-disabled='true']"),
			image: imageEvidence(element),
			requirementLabels: requirementLabels(element),
			ancestorTrail: ancestorTrail(element),
			form: form ? {
				id: technicalValue(form.id),
				name: technicalValue(form.getAttribute("name")),
				action: safePath(form.action)
			} : null,
			nearbyText: nearbyText(element)
		};
	}
	function pageEvidence() {
		return {
			pageKind: detectSisPage(document),
			path: location.pathname,
			isTopFrame: window === window.top
		};
	}
	async function send(message) {
		try {
			return await chrome.runtime.sendMessage(message);
		} catch {
			captureEnabled = false;
			updatePanel("Extension reloaded. Reload this SIS tab.");
			return;
		}
	}
	async function record(kind, control) {
		if (!captureEnabled) return;
		const response = await send({
			type: "SIS_DIAGNOSTIC_EVENT",
			event: {
				protocolVersion: 1,
				kind,
				recordedAt: (/* @__PURE__ */ new Date()).toISOString(),
				page: pageEvidence(),
				control: control || null
			}
		});
		if (typeof response?.count === "number") capturedEventCount = response.count;
		updatePanel();
	}
	function clickedElement(event) {
		const pathElement = event.composedPath().find((item) => item instanceof HTMLElement);
		if (!(pathElement instanceof HTMLElement)) return null;
		return pathElement.closest("a, button, input, select, [role='button'], [onclick]") || pathElement;
	}
	function handleClick(event) {
		if (!captureEnabled) return;
		const host = document.getElementById(HOST_ID);
		if (host && event.composedPath().includes(host)) return;
		const element = clickedElement(event);
		if (!element) return;
		record("click", controlEvidence(element));
		window.setTimeout(() => {
			if (!captureEnabled || !element.isConnected) return;
			record("settled", controlEvidence(element));
		}, 1200);
	}
	function panelMarkup(message = "") {
		return `
    <style>
      :host{all:initial}.panel{position:fixed;left:14px;bottom:14px;z-index:2147483647;width:250px;padding:12px;border:1px solid #aabcb0;border-radius:12px;background:#fbfcf9;color:#142019;box-shadow:0 14px 40px rgba(0,0,0,.22);font:12px/1.4 system-ui,sans-serif}.head{display:flex;align-items:center;justify-content:space-between;gap:8px}.title{font-size:13px;font-weight:800;color:#0b5b43}.status{font-size:11px;color:#637068}.actions{display:grid;grid-template-columns:1fr 1fr;gap:6px;margin-top:10px}button{min-height:34px;padding:0 9px;border:1px solid #bdc9c0;border-radius:8px;background:#fff;color:#203028;cursor:pointer;font-weight:700}.primary{border-color:#0b5b43;background:#0b5b43;color:#fff}.message{min-height:16px;margin-top:7px;color:#68756c;font-size:10px}
    </style>
    <aside class="panel" aria-label="SIS diagnostic capture">
      <div class="head"><span class="title">SIS diagnostic capture</span><span class="status">${captureEnabled ? `Capturing · ${capturedEventCount}` : `${capturedEventCount} events saved`}</span></div>
      <div class="actions">
        <button class="primary" id="toggle">${captureEnabled ? "Stop capture" : "Start capture"}</button>
        <button id="copy">Copy JSON</button>
        <button id="clear">Clear</button>
      </div>
      <div class="message" id="message">${message}</div>
    </aside>`;
	}
	function updatePanel(message = "") {
		if (window !== window.top) return;
		let host = document.getElementById(HOST_ID);
		if (!host) {
			host = document.createElement("div");
			host.id = HOST_ID;
			document.documentElement.append(host);
		}
		const shadow = host.shadowRoot || host.attachShadow({ mode: "open" });
		shadow.innerHTML = panelMarkup(message);
		shadow.getElementById("toggle")?.addEventListener("click", async () => {
			const response = await send({ type: captureEnabled ? "STOP_SIS_DIAGNOSTIC" : "START_SIS_DIAGNOSTIC" });
			captureEnabled = Boolean(response?.enabled);
			capturedEventCount = typeof response?.count === "number" ? response.count : capturedEventCount;
			updatePanel(captureEnabled ? "Capture only the failing SIS actions." : "Capture stopped.");
		});
		shadow.getElementById("copy")?.addEventListener("click", async () => {
			const response = await send({ type: "EXPORT_SIS_DIAGNOSTIC" });
			if (typeof response?.json !== "string") {
				updatePanel("Nothing to copy yet.");
				return;
			}
			await navigator.clipboard.writeText(response.json);
			updatePanel("Diagnostic JSON copied.");
		});
		shadow.getElementById("clear")?.addEventListener("click", async () => {
			const response = await send({ type: "CLEAR_SIS_DIAGNOSTIC" });
			capturedEventCount = typeof response?.count === "number" ? response.count : 0;
			updatePanel("Saved events cleared.");
		});
	}
	chrome.runtime.onMessage.addListener((message) => {
		if (message.type !== "SIS_DIAGNOSTIC_MODE") return;
		captureEnabled = Boolean(message.enabled);
		if (typeof message.count === "number") capturedEventCount = message.count;
		updatePanel();
		if (captureEnabled) record("page-ready");
	});
	document.addEventListener("click", handleClick, true);
	send({ type: "GET_SIS_DIAGNOSTIC" }).then((response) => {
		captureEnabled = Boolean(response?.enabled);
		capturedEventCount = typeof response?.count === "number" ? response.count : 0;
		updatePanel();
		if (captureEnabled) record("page-ready");
	});
	//#endregion
})();
